package model

data class Book (
        val bookId:String,
        val bookname: String,
        val bookAuthor: String,
        val bookrating:String,
        val bookPrice:String,
        val bookimage: String
)
